Thanks for purchasing the Universal Human: Female Base Mesh!

Before using this product, please ensure you have read the License Agreement at https://sites.google.com/view/universalhuman/license-agreement

Note for users of Blender 2.80 and higher: To maintain compatibility, the .blend file was created in Blender 2.79, which means the 2.79 UI layout will be loaded (complete with footers instead of headers). To prevent this, uncheck "Load UI" in Blender's File View before loading the file.

To use this mesh to add genders to the Body Rig, follow the assembly instructions here: https://sites.google.com/view/universalhuman/documentation/rig-mesh-assembly

To maintain compatibility with the Body Rig and Body & Face Rig, a partial rig is included to correct shoulder width and arm carrying angle.  If you don't intend to use this mesh with the rig, you may wish to Apply the Armature Modifier and delete the armature object.  By applying the modifier, those proportions are permanently transferred to the mesh and the armature is no longer needed.

Blender 2.79 Note: When using the mesh with the Body Rig or Body & Face Rig, the Gender control morphs to the appropriate symbol when rotated.  In Blender 2.79 this only works if the object providing the Gender control bone's custom shape is visible.  To see the control morphing you'll need to find the "Bone Shape Gender" object on layer 20 and move it to a visible layer.

Version updates are outlined in the Release Log here: https://sites.google.com/view/universalhuman/release-log

If you have any questions or issues, feel free to contact me at the address on this page: https://sites.google.com/view/universalhuman/contact

Thanks again!

Chris Jones
www.chrisj.com.au