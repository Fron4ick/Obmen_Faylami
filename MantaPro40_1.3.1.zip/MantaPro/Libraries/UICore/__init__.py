# Copyright (C) 2022-2023 Reston Stanton

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
from .uiCore import Core
from . import panel_list


NAME = "CorePanels"


def register():
    # import at register time so that the panels list is full
    from .import props
    bpy.utils.register_class(props.PanelProps)
    exec(
        f"bpy.types.WindowManager.{NAME} = bpy.props.PointerProperty(type=props.PanelProps)")


def unregister():
    from .import props
    bpy.utils.unregister_class(props.PanelProps)
    exec(f"del bpy.types.WindowManager.{NAME}")


def add(name: str, default=False):
    # append to list in panel_list file so it can be imported into the props file
    panel_list.panels.append((name, default))


def get_panels(context: bpy.context):
    return eval(f"context.window_manager.{NAME}")
