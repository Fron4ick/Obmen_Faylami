# Copyright (C) 2022-2023  Reston Stanton

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import bpy
import contextlib


@contextlib.contextmanager
def if_sub_context_manager(skip, core):
    # original code from https://stackoverflow.com/a/59736747
    skip_error = ValueError("Skipping Context Exception")
    prev_entered = getattr(if_sub_context_manager, "entered", False)
    if_sub_context_manager.entered = False

    def command():
        if_sub_context_manager.entered = True
        if not skip:
            raise skip_error

    try:
        yield command
    except ValueError as err:
        if err != skip_error:
            raise
    finally:
        core.exit_sub()
        assert if_sub_context_manager.entered, "Need to call returned command at least once. \n with self.sub_panel(data, value) as sub:\n    sub()  <-----"
        if_sub_context_manager.entered = prev_entered


class Core(bpy.types.Panel):
    LEGACY_IF_SUB = False

    def __init__(self):
        self._active_layout = self.layout
        self._active_layout_id = {"layout": "layout",
                                  "align": False,
                                  "box": False}
        self._layouts = [self._active_layout]
        self._layout_ids = [self._active_layout_id.copy()]

        self._disabled = False
        self._alert = False

        self._scale_y = 1
        self._scale_x = 1

    @ classmethod
    def poll(cls, context):
        return True

    def sub(self, align=False, box=True):
        """Create a sub layout

        sub layout is always a column"""
        # sub column layout
        if box:
            self._layouts.append(self._layouts[-1].box().column(align=align))
        else:
            self._layouts.append(self._layouts[-1].column(align=align))

        # set ui_type
        self._active_layout_id["layout"] = "col"
        self._active_layout_id["align"] = align
        self._active_layout_id["box"] = box

        self._active_layout = self._layouts[-1]
        self._layout_ids.append(self._active_layout_id.copy())

    def exit_sub(self):
        """Exit a sub layout and return to the previous sub layout"""
        index = len(self._layouts) - 1

        self._active_layout = self._layouts[index-1]
        self._layouts.pop(index)

        self._active_layout_id = self._layout_ids[index-1]
        self._layout_ids.pop(index)

    def sub_panel(self, data, property: str, text="", icon=None, box_header=True, fade=False, extra_row=None, extra_row_args=()):
        """Create a sub layout that looks like a panel

        ### Example:

        with self.sub_panel(data, property, text, box_header, fade, extra_row_function, extra_row_args=(argument,)) as sub:
            sub()
             # UI code to draw if panel is open
         # UI code after panel

        ## Extra row:
        extra_row: a function containing UI code for operators or labels to display in panel header
        extra_row should be a function with the first argument as row followed by any optional arguments 

        ### Example:

        def extra_row(row, argument1):
            # standred Blender UI drawing code for extra row


        ## LEGACY_IF_SUB:
        if LEGACY_IF_SUB is True then sub_panel can not use the --WITH-- statement and must exit after each sub

        ### Example:

        if self.sub_panel(data, property, text, box_header, fade extra_row_function, extra_row_args=(argument,)):
            # UI code to draw if panel is open
        self.exit_sub()
         # UI code after panel
        """
        if box_header:
            self.sub()

        # get row layout
        row = self._layouts[-1].row(align=True)
        row.active = not fade

        # set text if none
        if not text:
            text = property.replace("_", " ").capitalize()

        # set arrow icon
        show = eval("data." + property)
        if show:
            a_icon = "DOWNARROW_HLT"
            # a_icon = "DISCLOSURE_TRI_DOWN"
        else:
            a_icon = "RIGHTARROW"
            # a_icon = "DISCLOSURE_TRI_RIGHT"

        # if icon draw 2 props one with the arrow and the other with the icon
        if icon is None:
            row.prop(data, property, text=text, icon=a_icon, emboss=False)
        else:
            row.prop(data, property, text="", icon=a_icon, emboss=False)
            if type(icon) == str:
                row.prop(data, property, text=text, icon=icon, emboss=False)
            else:
                row.prop(data, property, text=text,
                         icon_value=icon, emboss=False)

        if not extra_row is None:
            row.emboss = 'PULLDOWN_MENU'
            extra_row(row, *extra_row_args)

        row.emboss = "NORMAL"
        if not box_header:
            if show:
                self.sub()
            else:
                self.sub(box=False)

        if self.LEGACY_IF_SUB:
            return show
        return if_sub_context_manager(show, self)

    def set_layout(self, layout_type: str, align=False, box=False, reset=False):
        """set the layout type

        Valid layout_type ('col', 'row')

        reset: sets the alert and disabled status to False and sets the scale to 1
        """

        # column layout
        if layout_type == 'col':
            if box:
                self._active_layout = self._layouts[-1].box().column(
                    align=align)
            else:
                self._active_layout = self._layouts[-1].column(align=align)
        # row layout
        elif layout_type == 'row':
            if box:
                self._active_layout = self._layouts[-1].box().row(align=align)
            else:
                self._active_layout = self._layouts[-1].row(align=align)

        # reset layout attributes
        if reset:
            # reset disable
            self._active_layout.enabled = True
            self._disabled = False
            # reset alert
            self.alert(False)
            self._alert = False
            # reset scale
            self._active_layout.scale_y = 1
            self._active_layout.scale_x = 1
            self._scale_y = 1
            self._scale_x = 1
        else:
            self._active_layout.enabled = not self._disabled
            self._active_layout.scale_y = self._scale_y
            self._active_layout.scale_x = self._scale_x

        # set ui_type
        self._active_layout_id["layout"] = layout_type
        self._active_layout_id["align"] = align
        self._active_layout_id["box"] = box

        self._layout_ids[-1] = self._active_layout_id.copy()

    def reset(self):
        """Reset the layout
        sets the alert and disabled status to False, sets the scale to 1, and sets the layout
        """
        self.set_layout(
            self._active_layout_id["layout"], self._active_layout_id["align"], reset=True, box=self._active_layout_id["box"])

    def prop(self, data, prop: str, text=None, icon="NONE", icon_only=False, invert_checkbox=False, slider=False, correct_slider=True, expand=False, emboss=True):
        """draws Property

        correct_slider: adds an extra 2 spaces to the begaining of text if slider=True"""
        if text and slider and correct_slider:
            text = "  " + text
        self._active_layout.prop(data, prop, text=text, icon=icon,
                                 icon_only=icon_only, invert_checkbox=invert_checkbox, slider=slider, expand=expand, emboss=emboss)

    def icon_prop(self, data, prop: str,  text="", icon_on="CHECKBOX_HLT", icon_off="CHECKBOX_DEHLT", icon_only=False, invert=False, expand=False, emboss=True):
        """draws a property with a icon"""
        if eval("data." + prop):
            icon = icon_on
        else:
            icon = icon_off

        if text:
            self._active_layout.prop(data, prop, icon=icon,
                                     text=text, invert_checkbox=invert, expand=expand, emboss=emboss)
        else:
            self._active_layout.prop(data, prop, icon=icon,
                                     icon_only=icon_only, invert_checkbox=invert, expand=expand, emboss=emboss)

    def label_prop(self, data, prop: str, text="", label_icon="NONE", prop_icon="NONE", emboss=True, as_row=False, row_align=True):
        """draw a label with the property below it

        as_row: makes the label prop exit with row as the active layout
        row_align: makes the row aligned if as_row == True (default is True)
        """
        if not text:
            text = prop.replace("_", " ").capitalize()
        else:
            text += ":"
        if as_row:
            self.set_layout("col")
            self.label(text=text, icon=label_icon)
            self.set_layout("row", align=row_align)
        else:
            self.label(text=text, icon=label_icon)
        self.prop(data, prop, text="", icon=prop_icon, emboss=emboss)

    def node_prop(self, prop, text: str = None, emboss=True):
        """draw a property specificity from a node"""
        if text is None:
            text = prop.node.name + " " + prop.name.capitalize()
        self.prop(prop, "default_value", text=text, emboss=emboss)

    def label_node_prop(self, prop, text: str = None, icon="NONE"):
        """draw a label above a property specificity from a node"""
        if text is None:
            text = prop.node.name + " " + prop.name
        if type(icon) is str:
            self.label(text=text, icon=icon)
        else:
            self.label(text=text, icon_value=icon)
        self.node_prop(prop, text="")

    def prop_search(self, data, prop, search_data, search_prop, text=None, icon="NONE"):
        """draw a property search"""
        self._active_layout.prop_search(
            data, prop, search_data, search_prop, text=text, icon=icon)

    def _operator_settings(self, operator: str, settings: dict, text=None, icon="NONE", emboss=True):
        """# INTERNAL"""
        op = self.operator(operator, text=text, icon=icon, emboss=emboss)

        for key in settings.keys():
            if type(settings[key]) is str:
                action = "op." + str(key) + " = '" + str(settings[key]) + "'"
            else:
                action = "op." + str(key) + " = " + str(settings[key])

            exec(action)
        return op

    def operator(self, operator: str, text: str = None, icon: any = "NONE", emboss=True, settings: dict = None):
        """draw an operator

        icon: can be either and int or string
        settings: a dictanary containing the property name and value

        Example:
        self.operator(operator, text, icon, emboss, settings={'prop_name': value})"""
        if settings is None:
            if type(icon) is str:
                return self._active_layout.operator(operator, text=text, icon=icon, emboss=emboss)
            else:
                return self._active_layout.operator(operator, text=text, icon_value=icon, emboss=emboss)
        else:
            return self._operator_settings(operator, text=text, icon=icon, settings=settings, emboss=emboss)

    def label(self, text="", icon="NONE"):
        """draw a label"""
        if type(icon) is str:
            self._active_layout.label(text=text, icon=icon)
        else:
            self._active_layout.label(text=text, icon_value=icon)

    def separator(self, factor=1.0):
        """add separator between properties"""
        self._active_layout.separator(factor=factor)

    # def separator_spacer(self):
    #     self._active_layout.separator_spacer()

    def disable(self, value=True):
        """disable the active layout"""
        if self._disabled and value:
            return
        self._active_layout.enabled = not value
        self._disabled = value

    def disable_root(self, value=True):
        """disable the root layout"""
        self._layouts[-1].enabled = not value
        self._disabled = value

    @ property
    def ui(self) -> bpy.types.UILayout:
        """active layout for manual UI drawing"""
        return self._active_layout

    def alert(self, value=True):
        """alert the layout and make it red"""
        self._active_layout.alert = value
        self._alert = value

    def active(self, value=True):
        """make the layout active

        if not active, layout will be gray but still function
        """
        self._active_layout.active = value

    def emboss(self, use_emboss: bool = None, emboss_type="NORMAL"):
        """Set the Emboss for the layout

        Valid emboss_type ('NORMAL', 'NONE', 'PULLDOWN_MENU', 'RADIAL_MENU', 'NONE_OR_STATUS')
         """
        self._active_layout.emboss = emboss_type

    def scale(self, value=1, axis="Y"):
        """Change the UI scale along an axis

        Valid axis ('X', 'Y')
        """
        if axis == "Y":
            self._active_layout.scale_y = value
            self._scale_y = value
        elif axis == "X":
            self._active_layout.scale_x = value
            self._scale_x = value
