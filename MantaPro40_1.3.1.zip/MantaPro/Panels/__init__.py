# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from .domain import *
from .flow import *
from .effector import *
from .force import *
from .other import *

from ..Liquid import Panels as Liquid_Panels
from ..Gas import Panels as Gas_Panels
from ..Effects import Panels as Effects_Panels


def MP_order_id_sorter(item):
    return item.MP_order_id


classes = [
    OBJECT_UL_domains,
    OBJECT_UL_flows,
    OBJECT_UL_effector,
    OBJECT_UL_force,
    VIEW3D_PT_ALL_AutoOpsSettings,
    VIEW3D_PT_ALL_Workspace,
    # domain
    VIEW3D_PT_SIM_MantaPro,
    VIEW3D_PT_SIM_MantaProDomain,

    # flow
    VIEW3D_PT_SIM_MantaProFlowMain,
    VIEW3D_PT_SIM_MantaProFlow,
    VIEW3D_PT_SIM_FlowSourceSub,
    # effector
    VIEW3D_PT_SIM_MantaProEffectorMain,
    VIEW3D_PT_SIM_MantaProEffector,
    VIEW3D_PT_SIM_EffectorDisplaySubGas,
    # force
    VIEW3D_PT_SIM_MantaProForceMain,
    VIEW3D_PT_SIM_MantaProForce,
    VIEW3D_PT_SIM_MantaProForceFalloff,
    VIEW3D_PT_SIM_MantaProForceKink,
    VIEW3D_PT_SIM_MantaProForceTexture,
    VIEW3D_PT_SIM_MantaProForceTextureSettings,
    VIEW3D_PT_SIM_ForceTextureColorSub,
    VIEW3D_PT_SIM_MantaProForceFalloffRadial,
    # advanced particle

    VIEW3D_PT_ALL_MantaProPanelPaint,
    VIEW3D_PT_SIM_SaveSetup,
    VIEW3D_PT_SIM_RemoveSetup,
    VIEW3D_PT_SIM_ExportImportSetup,
    VIEW3D_PT_SIM_ViewSetup,

    VIEW3D_PT_SIM_DomainMaterialSub,
    VIEW3D_PT_SIM_DomainGuidesSub,
    VIEW3D_PT_SIM_DomainCollectionsSub,
    VIEW3D_PT_SIM_DomainBorderSub,
    VIEW3D_PT_SIM_DomainFieldSub,
    VIEW3D_PT_SIM_DomainAdvancedSub,
    VIEW3D_PT_SIM_FlowVelocitySub,

    VIEW3D_PT_SIM_Viewport,
    VIEW3D_PT_SIM_ViewportVector,

    # blender

    VIEW3D_PT_SIM_DomainBorderBlenderSub,

    VIEW3D_PT_SIM_BlenderGuides,
    VIEW3D_PT_SIM_BlenderCollections,
    VIEW3D_PT_SIM_BlenderCache,
    VIEW3D_PT_SIM_BlenderCacheAdvanced,
    VIEW3D_PT_SIM_BlenderFieldWeights,
    VIEW3D_PT_SIM_BlenderViewport,
    VIEW3D_PT_SIM_BlenderViewportSlice,
    VIEW3D_PT_SIM_BlenderViewportGrid,
    VIEW3D_PT_SIM_BlenderViewportVector,

    VIEW3D_PT_SIM_DomainBlenderToolsSub,
    VIEW3D_PT_SIM_DomainMaterailBlenderToolsSub,
    VIEW3D_PT_SIM_CacheBlenderToolsSub,

    VIEW3D_PT_SIM_FlowSourceBlender,
    VIEW3D_PT_SIM_FlowVelocityBlender,

    VIEW3D_PT_SIM_AdvancedGravitySub,
    VIEW3D_PT_SIM_AdvancedCacheSub,
    VIEW3D_PT_SIM_FlowDisplaySubGas,
    VIEW3D_PT_ALL_DEV, ]


liquid_classes = Liquid_Panels.get()
gas_classes = Gas_Panels.get()
effects_classes = Effects_Panels.get()

classes.extend(liquid_classes)
classes.extend(gas_classes)
classes.extend(effects_classes)

classes.sort(key=MP_order_id_sorter)


def get_new_order():
    """Used for the MP_orderer.py devtool"""
    print("\n\n")
    classes_dict = {}
    for i in range(0, len(classes)):
        classes_dict[str(classes[i].__name__)] = i

    print("classes = {")
    for i in classes_dict.keys():
        print("'" + i + "':", str(classes_dict[i]) + ",")
    print("}")
    print("\n\n")


def register():
    # get_new_order()

    base = os.path.abspath(os.path.dirname(__file__))
    file = os.path.join(os.path.dirname(base), "Preferences", "abreveate_tab")
    if os.path.exists(file):
        for i in classes:
            i.bl_category = "MP"
    for i in classes:
        bpy.utils.register_class(i)


def unregister():
    for i in classes:
        bpy.utils.unregister_class(i)
