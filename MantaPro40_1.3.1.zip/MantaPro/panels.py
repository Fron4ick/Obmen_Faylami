"""A covenant place to access the add() and  get_panels() functions from the UICore"""

from .Libraries.UICore import add, get_panels
