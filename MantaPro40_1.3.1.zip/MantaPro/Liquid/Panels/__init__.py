# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy

from .domain import *
from .flow import *
from .effector import *


_classes = [VIEW3D_PT_SIM_DomainParticelsSub,
            VIEW3D_PT_SIM_DomainParticelsCustomSub,
            VIEW3D_PT_SIM_AdvancedParticelsSub,
            VIEW3D_PT_SIM_AdvancedDiffusionSub,
            VIEW3D_PT_SIM_AdvancedLiquidSub,
            VIEW3D_PT_SIM_AdvancedMeshSub,

            # blender
            VIEW3D_PT_SIM_BlenderLiquid,
            VIEW3D_PT_SIM_BlenderViscosity,
            VIEW3D_PT_SIM_BlenderDiffusion,
            VIEW3D_PT_SIM_BlenderParticles,
            VIEW3D_PT_SIM_BlenderMesh,
            VIEW3D_PT_SIM_DomainParticleBlenderToolsSub, ]


def get():
    return list(_classes)
