# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ...Shared import uiCore, ui, polls, particles
from ... import Icons


class VIEW3D_PT_EFFECT_Ember(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Add"
    MP_order_id = 2

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Ember", icon_value=Icons.get_icon_id("ember"))

    def draw(self, context):
        self.set_layout("col", box=True)
        self.label(text="It is Recommended to Bake the Fluid", icon="INFO")
        self.label(text="Simulation Before Setting up an Ember System")
        # ui.ember(self, context)


class VIEW3D_PT_EFFECT_EmberSettings(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Ember"
    MP_order_id = 2

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="General Settings", icon="SETTINGS")

    def draw(self, context):
        ui.ember(self, context)


class VIEW3D_PT_EFFECT_EmberParticle(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Ember"
    MP_order_id = 3

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Particle Settings", icon="PARTICLES")

    def draw(self, context):
        ui.ember_particle(self, context)


class VIEW3D_PT_EFFECT_EmberCustomParticle(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_EmberParticle"
    MP_order_id = 3

    bl_options = {'DEFAULT_CLOSED'}

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Custom Particles",
                          icon="MOD_PARTICLE_INSTANCE")

    def draw(self, context):
        ui.ember_custom_particles(self, context)


class VIEW3D_PT_EFFECT_EmberForce(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Ember"
    MP_order_id = 4

    bl_options = {'DEFAULT_CLOSED'}

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Force Settings", icon="FORCE_FORCE")

    def draw(self, context):
        ui.ember_force(self, context)


class VIEW3D_PT_EFFECT_EmberForceFalloff(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_EmberForce"
    MP_order_id = 4

    bl_options = {'DEFAULT_CLOSED'}

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Falloff")

    def draw(self, context):
        ui.ember_force_falloff(self, context)


class VIEW3D_PT_EFFECT_EmberForceFalloff(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_EmberForce"
    MP_order_id = 4

    bl_options = {'DEFAULT_CLOSED'}

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Falloff")

    def draw(self, context):
        ui.ember_force_falloff(self, context)


class VIEW3D_PT_EFFECT_EmberCache(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Ember"
    MP_order_id = 5

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Cache Settings", icon="FILE")

    def draw(self, context):
        ui.ember_cache(self, context)


class VIEW3D_PT_EFFECT_EmberMaterial(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Ember"
    MP_order_id = 5

    @ classmethod
    def poll(cls, context):
        return polls.EMBER(context)

    def draw_header(self, context):
        self.layout.label(text="Material Settings", icon="MATERIAL")

    def draw(self, context):
        ui.ember_material(self, context)


_classes = (
    VIEW3D_PT_EFFECT_Ember,
    VIEW3D_PT_EFFECT_EmberSettings,
    VIEW3D_PT_EFFECT_EmberParticle,
    VIEW3D_PT_EFFECT_EmberCustomParticle,
    VIEW3D_PT_EFFECT_EmberForce,
    VIEW3D_PT_EFFECT_EmberForceFalloff,
    VIEW3D_PT_EFFECT_EmberCache,
    VIEW3D_PT_EFFECT_EmberMaterial,
)


def get():
    return list(_classes)
