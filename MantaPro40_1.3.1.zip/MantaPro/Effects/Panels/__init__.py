# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ...Shared import uiCore, ui, polls, particles
from ... import Icons

from . import ember, v_mod, ocean


class OBJECT_UL_effects(bpy.types.UIList):
    MP_order_id = 1

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if not item.name:
            return
        ob = data

        if self.layout_type in {'DEFAULT'}:
            # get icon
            if item.type == "V_MOD":
                icon = Icons.get_icon_id("v_mod")
            elif item.type == "EMBER":
                icon = Icons.get_icon_id("ember")
            elif item.type == "OCEAN":
                icon = 478

            layout.scale_x = 1
            layout.label(icon_value=icon)
            layout.prop(item, "name", text="", emboss=False)


class VIEW3D_PT_EFFECT_Add(uiCore.Core, bpy.types.Panel):
    bl_label = ""  # MantaPro Domain
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    MP_order_id = 1

    def draw_header(self, context):
        self.layout.label(text="Effects",)

    def draw(self, context):
        settings = context.scene.MantaPro
        self.set_layout("col")
        self.ui.operator_menu_enum(
            'mantapro_effects.add', 'effect_type', text='Add Effect', icon='ADD')

        # self.set_layout("row")
        self.ui.template_list("OBJECT_UL_effects", "", settings,
                              "effects", settings, "effects_index")
        self.operator('mantapro_effects.remove', icon="X",
                      text="Remove Active Effect")


_classes = [OBJECT_UL_effects,
            VIEW3D_PT_EFFECT_Add, ]


def get():
    _classes.extend(ember.get())
    _classes.extend(v_mod.get())
    _classes.extend(ocean.get())
    return list(_classes)
