# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ...Shared import uiCore, ui, polls, particles
from ... import Icons
from ... import panels
from ... import preferences

from .. import v_mod


class VIEW3D_PT_EFFECT_VMod(uiCore.Core, bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MantaPro"
    bl_context = "objectmode"
    bl_parent_id = "VIEW3D_PT_EFFECT_Add"
    MP_order_id = 2

    # add panels
    panels.add("v_mod_edit", False)
    panels.add("v_mod_mix", False)
    panels.add("v_mod_prox", False)

    panels.add("v_mod_experimental", False)

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD(context)

    def draw_header(self, context):
        self.layout.label(text="Vertex Modify", icon="GROUP_VERTEX")

    def draw(self, context):
        p_ids = panels.get_panels(context)
        self.set_layout("col")
        v_mod.ui_check(self, context)

        # TODO PROXIMITY GOES HERE

        with self.sub_panel(p_ids, "v_mod_mix", text="Mix", icon="RNA", box_header=False, extra_row=v_mod.ui_header, extra_row_args=("MIX",)) as sub:
            sub()
            v_mod.ui_draw_mix(self, context)

        with self.sub_panel(p_ids, "v_mod_edit", text="Edit", icon="EDITMODE_HLT", box_header=False, extra_row=v_mod.ui_header, extra_row_args=("EDIT",)) as sub:
            sub()
            v_mod.ui_draw_edit(self, context)

        # EXPERIMENTAL
        if preferences.get_preferences().EXPERIMENTAL:
            with self.sub_panel(p_ids, "v_mod_experimental", text="EXPERIMENTAL", icon="ERROR", box_header=False) as sub:
                sub()
                with self.sub_panel(p_ids, "v_mod_prox", text="Proximity", icon="UV_FACESEL", box_header=False, extra_row=v_mod.ui_header, extra_row_args=("PROX",)) as sub:
                    sub()
                    v_mod.ui_draw_prox(self, context)


_classes = [VIEW3D_PT_EFFECT_VMod,
            ]


def get():
    return list(_classes)
