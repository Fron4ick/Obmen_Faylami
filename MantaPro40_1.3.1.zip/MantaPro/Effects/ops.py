# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy

from .. import preferences
from ..Shared import ops, material, modifiers
from . import ember, v_mod, ocean


def re_index(effects):
    for i, key in enumerate(effects.keys()):
        effects[key].index = i


def set_effects_index(context, type):
    pre_keys = context.scene.MantaPro.effects.keys()
    item = context.scene.MantaPro.effects.add()

    # set name
    name = type.capitalize()
    while name in pre_keys:
        name = ops.rename(name)
    item.name = name

    item.type = type
    if len(pre_keys) == 0:
        context.scene.MantaPro.effects_index = 0
    else:
        item.index = context.scene.MantaPro.effects[pre_keys[-1]].index + 1
        context.scene.MantaPro.effects_index = item.index
    return item


class MantaProEffectsAdd(bpy.types.Operator):
    bl_idname = "mantapro_effects.add"
    bl_label = "Add Effect"
    bl_description = "add an effect to the scene"

    bl_options = {'REGISTER', 'UNDO'}

    effect_type: bpy.props.EnumProperty(name="Effector Type",
                                        items=[
                                            ("", "PreEffects", "", 0, 0),
                                            ("OCEAN", "Ocean to Liquid", "", 0, 1),
                                            # ("EXPLODE", "Explode Tools", "", 0, 2),

                                            ("", "VertexEffects", "", 0, 3),
                                            ("V_MOD", "Vertex Modify", "", 0, 4),
                                            # ("V_DYNAMIC", "Dynamic Vertex", "", 0, 5),

                                            ("", "PostEffects", "", 0, 6),
                                            ("EMBER", "Ember", "", 0, 7),
                                            # ("FLOAT", "Float on Liquid", "", 0, 8),
                                        ])

    @ classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=300)

    def execute(self, context):
        settings = context.scene.MantaPro
        # error checking
        # one ember
        if settings.active_flow:
            if settings.active_flow.MantaPro.is_ember and self.effect_type == 'EMBER':
                self.report(
                    {"ERROR"}, "Selected flow already contains and Ember effect")
                return {'CANCELLED'}

            if modifiers.check_type_liquid(settings.active_flow, "FLOW") and self.effect_type == 'V_MOD':
                self.report(
                    {"ERROR"}, "Vertex Modify effect is not support on a Liquid flow")
                return {'CANCELLED'}

        item = set_effects_index(context, self.effect_type)
        if self.effect_type == 'EMBER':
            ember.add(context, item)
        elif self.effect_type == 'V_MOD':
            v_mod.add(context, item)
        elif self.effect_type == 'OCEAN':
            ocean.add(context, item)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.MantaPro
        if self.effect_type == "EMBER":
            ember.ui_add_op(layout, settings)

        elif self.effect_type == "V_MOD":
            v_mod.ui_add_op(layout, settings)

        elif self.effect_type == "OCEAN":
            ocean.ui_add_op(layout, settings)


class MantaProEffectsRemove(bpy.types.Operator):
    bl_idname = "mantapro_effects.remove"
    bl_label = "Add Effect"
    bl_description = "add an effect to the scene"

    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return context.scene.MantaPro.effects

    def execute(self, context):
        settings = context.scene.MantaPro
        effect = settings.effects[settings.effects_index]
        if effect.type == 'EMBER':
            ember.remove(context)
        elif effect.type == 'V_MOD':
            v_mod.remove(context)
        elif effect.type == 'OCEAN':
            ocean.remove(context)
        settings.effects.remove(settings.effects_index)
        settings.effects_index = settings.effects_index - 1
        re_index(settings.effects)
        return {'FINISHED'}


classes = (
    MantaProEffectsAdd,
    MantaProEffectsRemove,
)


def register():
    for i in classes:
        bpy.utils.register_class(i)


def unregister():
    for i in classes:
        bpy.utils.unregister_class(i)
