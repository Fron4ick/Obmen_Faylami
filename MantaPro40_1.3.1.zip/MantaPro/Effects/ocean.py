# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ..Shared import uiCore, polls, modifiers
from .. import panels

"""
    ██████                                  █████     ███
   ███░░███                                ░░███     ░░░
  ░███ ░░░  █████ ████ ████████    ██████  ███████   ████   ██████  ████████    █████
 ███████   ░░███ ░███ ░░███░░███  ███░░███░░░███░   ░░███  ███░░███░░███░░███  ███░░
░░░███░     ░███ ░███  ░███ ░███ ░███ ░░░   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
  ░███      ░███ ░███  ░███ ░███ ░███  ███  ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
  █████     ░░████████ ████ █████░░██████   ░░█████  █████░░██████  ████ █████ ██████
 ░░░░░       ░░░░░░░░ ░░░░ ░░░░░  ░░░░░░     ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░



"""


def add_obj(context, effect):
    cursor = context.scene.cursor.location

    bpy.ops.mesh.primitive_grid_add(x_subdivisions=100, y_subdivisions=100, size=12,
                                    enter_editmode=False, align='WORLD', location=(cursor.x, cursor.y, cursor.z+4), scale=(1, 1, 1))

    ocean = context.active_object
    ocean.name = "MP-Ocean"
    ocean.hide_render = True
    ocean.MantaPro.is_ocean = True
    bpy.ops.mantapro.transparent_material(obj=ocean.name)

    effect.ocean = ocean
    return ocean


def add_solidify(ocean, effect):
    solidify_mod = ocean.modifiers.new("MP-Solidify", type='SOLIDIFY')
    solidify_mod.thickness = 7
    solidify_mod.show_expanded = False
    effect.solidify_mod = solidify_mod.name
    bpy.ops.object.modifier_move_to_index(modifier=solidify_mod.name, index=1)


def add_ocean(ocean, effect):
    ocean_mod = ocean.modifiers.new("MP-Ocean", type='OCEAN')
    ocean_mod.geometry_mode = 'DISPLACE'
    ocean_mod.size = 0.2
    ocean_mod.use_normals = True
    ocean_mod.show_expanded = False
    effect.ocean_mod = ocean_mod.name
    bpy.ops.object.modifier_move_to_index(modifier=ocean_mod.name, index=2)


def add_subdiv(ocean, effect):
    subdiv_mod = ocean.modifiers.new("MP-Subdiv", type='SUBSURF')
    subdiv_mod.levels = 0
    subdiv_mod.render_levels = 0
    subdiv_mod.show_expanded = False
    effect.subdiv_mod = subdiv_mod.name
    bpy.ops.object.modifier_move_to_index(modifier=subdiv_mod.name, index=0)


def add_fluid(ocean, effect):
    fluid_modifier = ocean.modifiers.new("Fluid", type='FLUID')
    fluid_modifier.fluid_type = 'FLOW'
    flow = fluid_modifier.flow_settings

    flow.flow_type = 'LIQUID'
    flow.flow_behavior = 'GEOMETRY'
    flow.use_initial_velocity = True
    flow.velocity_normal = 1.0


def add_all(context, effect):
    ocean = add_obj(context, effect)
    add_subdiv(ocean, effect)
    add_solidify(ocean, effect)
    add_ocean(ocean, effect)
    add_fluid(ocean, effect)


def add(context, item):
    effect = item.ocean
    effect.version = 1
    effect.domain = context.scene.MantaPro.active_domain

    add_all(context, effect)


def remove(context):
    settings = context.scene.MantaPro
    effect = settings.effects[settings.effects_index].ocean
    ocean = effect.ocean
    subdiv_mod = modifiers.get_modifier(ocean, effect.subdiv_mod)
    solidify_mod = modifiers.get_modifier(ocean, effect.solidify_mod)
    ocean_mod = modifiers.get_modifier(ocean, effect.ocean_mod)
    flow_mod = modifiers.find_modifier(ocean)

    if subdiv_mod and solidify_mod and ocean_mod and flow_mod:
        ocean.modifiers.remove(subdiv_mod)
        ocean.modifiers.remove(solidify_mod)
        ocean.modifiers.remove(ocean_mod)
        ocean.modifiers.remove(flow_mod)

        bpy.data.objects.remove(ocean)


"""
    ███████                                            █████
  ███░░░░░███                                         ░░███
 ███     ░░███ ████████   ██████  ████████   ██████   ███████    ██████  ████████   █████
░███      ░███░░███░░███ ███░░███░░███░░███ ░░░░░███ ░░░███░    ███░░███░░███░░███ ███░░
░███      ░███ ░███ ░███░███████  ░███ ░░░   ███████   ░███    ░███ ░███ ░███ ░░░ ░░█████
░░███     ███  ░███ ░███░███░░░   ░███      ███░░███   ░███ ███░███ ░███ ░███      ░░░░███
 ░░░███████░   ░███████ ░░██████  █████    ░░████████  ░░█████ ░░██████  █████     ██████
   ░░░░░░░     ░███░░░   ░░░░░░  ░░░░░      ░░░░░░░░    ░░░░░   ░░░░░░  ░░░░░     ░░░░░░
               ░███
               █████
              ░░░░░
"""


class MantaProEffectsOceanDisplayToggle(bpy.types.Operator):
    bl_idname = "mantapro_effects_ocean.display_toggle"
    bl_label = "Toggle display"
    bl_description = "Toggle the viewport display of the ocean between Textured and bounds"

    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return context.scene.MantaPro.effects

    def execute(self, context):
        settings = context.scene.MantaPro
        effect = settings.effects[settings.effects_index].ocean
        ocean = effect.ocean

        if ocean.display_type == 'TEXTURED':
            ocean.display_type = "BOUNDS"
        else:
            ocean.display_type = "TEXTURED"

        return {'FINISHED'}


class MantaProEffectsOceanAddMissing(bpy.types.Operator):
    bl_idname = "mantapro_effects_ocean.fix"
    bl_label = "Fix"
    bl_description = "Fix effect by adding missing modifiers"

    bl_options = {'REGISTER', 'UNDO'}

    type: bpy.props.StringProperty()

    @ classmethod
    def poll(cls, context):
        return context.scene.MantaPro.effects

    def execute(self, context):
        settings = context.scene.MantaPro
        effect = settings.effects[settings.effects_index].ocean
        ocean = effect.ocean
        solidify_mod = modifiers.get_modifier(ocean, effect.solidify_mod)
        ocean_mod = modifiers.get_modifier(ocean, effect.ocean_mod)
        subdiv_mod = modifiers.get_modifier(ocean, effect.subdiv_mod)

        if self.type == 'SOLIDIFY' and not solidify_mod:
            add_solidify(ocean, effect)
        elif self.type == 'OCEAN' and not ocean_mod:
            add_ocean(ocean, effect)
        elif self.type == 'SUBDIV' and not subdiv_mod:
            add_subdiv(ocean, effect)
        elif self.type == 'OBJ':
            bpy.data.objects.remove(ocean)
            add_all(context, effect)

        return {'FINISHED'}


"""
 █████  █████ █████
░░███  ░░███ ░░███
 ░███   ░███  ░███
 ░███   ░███  ░███
 ░███   ░███  ░███
 ░███   ░███  ░███
 ░░████████   █████
  ░░░░░░░░   ░░░░░



"""

panels.add("effect_ocean_waves")
panels.add("effect_ocean_extra")
panels.add("effect_ocean_resolution")


def ui_draw(self: uiCore.Core, context: bpy.context):
    # initial vars
    panel = panels.get_panels(context)
    settings = context.scene.MantaPro
    effect = settings.effects[settings.effects_index].ocean
    domain = effect.domain
    ocean = effect.ocean
    solidify_mod = modifiers.get_modifier(ocean, effect.solidify_mod)
    ocean_mod = modifiers.get_modifier(ocean, effect.ocean_mod)
    subdiv_mod = modifiers.get_modifier(ocean, effect.subdiv_mod)

    if ocean_mod and solidify_mod and subdiv_mod and ocean.users_scene:
        self.set_layout("col")
        self.prop(solidify_mod, "thickness")
        self.operator("mantapro_effects_ocean.display_toggle")

        self.separator()
        self.label_prop(ocean_mod, "spectrum", text="Ocean Type")

        if ocean_mod.spectrum in ['TEXEL_MARSEN_ARSLOE', 'JONSWAP']:
            with self.sub_panel(panel, "effect_ocean_extra", text="Extras", fade=True) as sub:
                sub()
                self.set_layout("col")
                self.prop(ocean_mod, "sharpen_peak_jonswap",
                          slider=True, correct_slider=True)
                self.prop(ocean_mod, "fetch_jonswap")
        else:
            self.separator()

        self.prop(ocean_mod, "wave_scale")
        self.prop(effect, "scale", text="Object Scale")

        self.separator()
        self.prop(ocean_mod, "size")
        self.prop(ocean_mod, "spatial_size")
        self.separator()

        self.set_layout("row")
        self.prop(ocean_mod, "time")
        self.icon_prop(effect, "animate_time",  icon_on="DECORATE_DRIVER",
                       icon_off="DECORATE", icon_only=True, emboss=True)
        self.set_layout("col")
        if effect.animate_time:
            self.prop(effect, "animation_speed", slider=True)

        self.prop(effect, "power")

        self.separator()
        with self.sub_panel(panel, "effect_ocean_resolution", text="Resolution", box_header=False) as sub:
            sub()
            self.set_layout("col", align=True)
            self.prop(ocean_mod, "viewport_resolution", text="Viewport")
            self.prop(ocean_mod, "resolution", text="Render")
            self.separator()
            self.prop(effect, "subdiv_levels")

        with self.sub_panel(panel, "effect_ocean_waves", text="Waves", box_header=False) as sub:
            sub()
            self.set_layout("col")
            self.prop(ocean_mod, "wave_scale_min", text="Detail")
            self.prop(ocean_mod, "choppiness")
            self.prop(ocean_mod, "wind_velocity")
            self.separator()

            self.prop(ocean_mod, "wave_alignment")

            self.set_layout("col")
            self.active(bool(ocean_mod.wave_alignment))
            self.prop(ocean_mod, "wave_direction")
            self.prop(ocean_mod, "damping")
    else:
        ui_missing_modifier(self, context)


def ui_missing_modifier(self: uiCore.Core, context: bpy.context):
    # initial vars
    settings = context.scene.MantaPro
    effect = settings.effects[settings.effects_index].ocean
    solidify_mod = modifiers.get_modifier(effect.ocean, effect.solidify_mod)
    ocean_mod = modifiers.get_modifier(effect.ocean, effect.ocean_mod)
    subdiv_mod = modifiers.get_modifier(effect.ocean, effect.subdiv_mod)

    if not effect.ocean.users_scene:
        self.set_layout("col")
        self.alert()
        self.label("Ocean Object is missing", icon='ERROR')
        self.operator("mantapro_effects_ocean.fix",
                      text="Fix Ocean", settings={"type": "OBJ"})

    if not subdiv_mod:
        self.set_layout("col")
        self.alert()
        self.label("Subdivision modifier is missing", icon='ERROR')
        self.operator("mantapro_effects_ocean.fix",
                      text="Fix Subdivision", settings={"type": "SUBDIV"})

    elif not solidify_mod:
        self.set_layout("col")
        self.alert()
        self.label("Solidify modifier is missing", icon='ERROR')
        self.operator("mantapro_effects_ocean.fix",
                      text="Fix Solidify", settings={"type": "SOLIDIFY"})

    elif not ocean_mod:
        self.set_layout("col")
        self.alert()
        self.label("Ocean modifier is missing", icon='ERROR')
        self.operator("mantapro_effects_ocean.fix",
                      text="Fix Ocean", settings={"type": "OCEAN"})


def ui_add_op(layout: bpy.types.UILayout, settings):
    col = layout.column()
    col.template_list("OBJECT_UL_domains", "", settings,
                      "domains", settings, "domains_index")
    col.separator()
    col.label(text="Ocean to Liquid will be added to selected the Domain")
    if not modifiers.check_type_liquid(settings.active_domain, "DOMAIN"):
        col = layout.column()
        col.alert = True
        col.label(
            text="Ocean to Liquid effect is not support on a Gas Domain", icon="ERROR")


classes = [MantaProEffectsOceanDisplayToggle,
           MantaProEffectsOceanAddMissing, ]


def register():
    for i in classes:
        bpy.utils.register_class(i)


def unregister():
    for i in classes:
        bpy.utils.unregister_class(i)
