# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ..Shared import overlays, modifiers, material, forces, particles


def add(context, item):
    effect = item.ember
    effect.version = 1

    flow = context.scene.MantaPro.active_flow
    effect.emitter_object = flow
    flow.MantaPro.is_ember = True

    # add particle system
    modifier = flow.modifiers.new(
        name="MantaPro Ember", type="PARTICLE_SYSTEM")

    system = modifier.particle_system
    settings = system.settings
    settings.name = "MantaPro Ember"
    settings.MantaPro.is_ember = True

    # setup particle system
    settings.frame_end = context.scene.frame_end + 1
    settings.effector_weights.gravity = 0.1
    settings.use_modifier_stack = True
    settings.normal_factor = 1.5
    settings.count = 450
    settings.lifetime = 150
    settings.lifetime_random = 0.8
    settings.brownian_factor = 1
    settings.particle_size = 0.3
    settings.size_random = 0.8
    settings.factor_random = 0.8

    settings.display_size = 0.05

    # setup sub forces system
    settings.use_self_effect = False
    settings.effector_amount = 50
    settings.force_field_1.type = "FORCE"
    settings.force_field_1.strength = 0.5
    settings.force_field_1.noise = 1
    settings.force_field_1.use_max_distance = True
    settings.force_field_1.distance_max = 0.05
    settings.force_field_1.use_gravity_falloff = True

    settings.force_field_1.use_min_distance = True
    settings.force_field_1.distance_min = 0.04

    # add force
    bpy.ops.mantapro.add_force(type="FLUID")
    force = context.active_object
    force.name = "EMBER FORCE"
    force.MantaPro.is_ember = True
    force.field.strength = 10
    effect.force_object = force

    if modifiers.check_type_gas(flow, "FLOW"):
        force.field.use_smoke_density = True
    else:
        force.field.use_smoke_density = False

    # move force to a new collection
    force_collections = force.users_collection
    for i in force_collections:
        i.objects.unlink(force)
    collection = bpy.data.collections.new("EMBER_FORCE")
    flow.users_collection[0].children.link(collection)
    collection.objects.link(force)

    # setup domain
    force.field.source_object = context.scene.MantaPro.active_domain
    effect.domain = context.scene.MantaPro.active_domain

    # add particle objects
    particle, collection = particles.add_ember_particles(context)
    effect.particle_object = particle

    settings.render_type = 'OBJECT'
    settings.instance_object = particle

    # hide render
    if flow.hide_render:
        flow.show_instancer_for_render = False
        flow.hide_render = False


def remove(context):
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].ember
    flow = effect.emitter_object
    flow.MantaPro.is_ember = False

    modifier = modifiers.find_ember_modifier(flow)
    particle = modifier.particle_system.settings.instance_object
    flow.modifiers.remove(modifier)

    force = effect.force_object
    if force:
        force.MantaPro.is_ember = False
        bpy.data.objects.remove(force)

        if context.scene.MantaPro.active_force == force:
            context.scene.MantaPro.active_force = None
            context.scene.MantaPro.forces_index = 0

    if particle:
        if "MantaPro_Ember" in particle.name:
            if particle.users == 2:
                collection = particle.users_collection[0]
                bpy.data.objects.remove(particle)
                if not collection.all_objects:
                    bpy.data.collections.remove(collection)

    # remove force collection
    for i in bpy.data.collections:
        if "EMBER_FORCE" in i.name:
            if not i.objects.items():
                bpy.data.collections.remove(i)

    # hide render
    if not flow.show_instancer_for_render:
        flow.hide_render = True


def ui_add_op(layout: bpy.types.UILayout, settings):
    col = layout.column()
    col.template_list("OBJECT_UL_flows", "", settings,
                      "flows", settings, "flows_index")
    col.separator()
    col.label(text="Ember will be added to selected the Flow")

    if settings.active_flow:
        if settings.active_flow.MantaPro.is_ember:
            col = layout.column()
            col.alert = True
            col.label(
                text="Selected flow already has an ember effect", icon="ERROR")
