# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ..Shared import uiCore, ui_textures, polls, modifiers
from .. import panels
from .. import Effects

"""
 ███████████                                 █████     ███
░░███░░░░░░█                                ░░███     ░░░
 ░███   █ ░  █████ ████ ████████    ██████  ███████   ████   ██████  ████████    █████
 ░███████   ░░███ ░███ ░░███░░███  ███░░███░░░███░   ░░███  ███░░███░░███░░███  ███░░
 ░███░░░█    ░███ ░███  ░███ ░███ ░███ ░░░   ░███     ░███ ░███ ░███ ░███ ░███ ░░█████
 ░███  ░     ░███ ░███  ░███ ░███ ░███  ███  ░███ ███ ░███ ░███ ░███ ░███ ░███  ░░░░███
 █████       ░░████████ ████ █████░░██████   ░░█████  █████░░██████  ████ █████ ██████
░░░░░         ░░░░░░░░ ░░░░ ░░░░░  ░░░░░░     ░░░░░  ░░░░░  ░░░░░░  ░░░░ ░░░░░ ░░░░░░
"""


def add(context, item):
    effect = item.v_mod
    effect.version = 1

    effect.prev_source = context.scene.MantaPro.active_flow
    effect.source = context.scene.MantaPro.active_flow

    flow = modifiers.find_modifier(effect.source)

    effect.vgroup = flow.flow_settings.density_vertex_group

    effect.source.MantaPro.is_vmod = True


def remove(context):
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    edit, mix, prox = modifiers.get_v_mod_all(effect, effect.source)
    if edit:
        remove_mod(context, "EDIT")
    if mix:
        remove_mod(context, "MIX")
    if prox:
        remove_mod(context, "PROX")

    effect.source.MantaPro.is_vmod = False


def remove_mod(context: bpy.context, type: str):
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    obj = effect.source
    mod = modifiers.get_v_mod(effect, obj, type)
    if mod:
        obj.modifiers.remove(mod)

    if type == "EDIT":
        effect.edit = ""
        effect.use_edit = False
    elif type == "MIX":
        effect.mix = ""
        effect.use_mix = False
    elif type == "PROX":
        effect.proximity = ""
        effect.use_proximity = False


def move(context: bpy.context, new_source, old_source, type: str):
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    mod = modifiers.get_v_mod(effect, old_source, type)

    if mod:
        # copy modifier
        override = {"object": old_source, "selected_objects": [old_source, new_source]}
        with context.temp_override(**override):
            bpy.ops.object.modifier_copy_to_selected(modifier=mod.name)

        # remove
        old_source.modifiers.remove(mod)

        # index modifier
        index_mod(context, effect, new_source, type)


def move_all(context: bpy.context, new_source, old_source):
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    if effect.use_edit:
        move(context, new_source, old_source, "EDIT")
    if effect.use_mix:
        move(context, new_source, old_source, "MIX")
    if effect.use_proximity:
        move(context, new_source, old_source, "PROX")


def index_mod(context: bpy.context, effect, obj, type: str):
    # get modifiers index
    index = 0
    edit, mix, prox = modifiers.get_v_mod_all(effect, obj)
    modifier = prox
    if type == "EDIT":
        # always add Below Mix
        if mix:
            index = modifiers.get_modifier_index(obj, mix.name) + 1
        elif prox:
            index = modifiers.get_modifier_index(obj, prox.name) + 1
        modifier = edit
    elif type == "MIX":
        # always add below VProx
        edit, mix, prox = modifiers.get_v_mod_all(effect, obj)
        if prox:
            index = modifiers.get_modifier_index(obj, prox.name) + 1
        modifier = mix

    # set index
    override = {"object": obj}
    with context.temp_override(**override):
        bpy.ops.object.modifier_move_to_index(modifier=modifier.name, index=index)


def add_mod(context: bpy.context, type: str):
    # get vars
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    obj = effect.source
    fluid_modifier = modifiers.find_modifier(obj).flow_settings

    # add modifier and set vertex_group
    if type == "EDIT":
        modifier = obj.modifiers.new("MP-Effects-V_EDIT", "VERTEX_WEIGHT_EDIT")
        effect.edit = modifier.name
        effect.use_edit = True
        modifier.vertex_group = fluid_modifier.density_vertex_group
    elif type == "MIX":
        modifier = obj.modifiers.new("MP-Effects-V_MIX", "VERTEX_WEIGHT_MIX")
        effect.mix = modifier.name
        effect.use_mix = True
        modifier.vertex_group_a = fluid_modifier.density_vertex_group
    elif type == "PROX":
        modifier = obj.modifiers.new(
            "MP-Effects-V_PROX", "VERTEX_WEIGHT_PROXIMITY")
        effect.proximity = modifier.name
        effect.use_proximity = True
        # defaults
        modifier.vertex_group = fluid_modifier.density_vertex_group
        modifier.proximity_mode = 'GEOMETRY'
        modifier.proximity_geometry = {'FACE'}
        modifier.min_dist = 0.25

    index_mod(context, effect, obj, type)

    # close modifier
    modifier.show_expanded = False


"""
    ███████                                            █████
  ███░░░░░███                                         ░░███
 ███     ░░███ ████████   ██████  ████████   ██████   ███████    ██████  ████████   █████
░███      ░███░░███░░███ ███░░███░░███░░███ ░░░░░███ ░░░███░    ███░░███░░███░░███ ███░░
░███      ░███ ░███ ░███░███████  ░███ ░░░   ███████   ░███    ░███ ░███ ░███ ░░░ ░░█████
░░███     ███  ░███ ░███░███░░░   ░███      ███░░███   ░███ ███░███ ░███ ░███      ░░░░███
 ░░░███████░   ░███████ ░░██████  █████    ░░████████  ░░█████ ░░██████  █████     ██████
   ░░░░░░░     ░███░░░   ░░░░░░  ░░░░░      ░░░░░░░░    ░░░░░   ░░░░░░  ░░░░░     ░░░░░░
               ░███
               █████
              ░░░░░
"""


class MantaProEffectsVEditEdit(bpy.types.Operator):
    bl_idname = "mantapro_v_edit.add"
    bl_label = "Edit"
    bl_description = "Add VEdit modifier"

    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return not polls.V_MOD_MOD(context, "EDIT")

    def execute(self, context):
        add_mod(context, "EDIT")

        # open panel
        # panel = panels.get_panels(context)
        # panel.v_mod_edit = True
        return {'FINISHED'}


class MantaProEffectsVMixAdd(bpy.types.Operator):
    bl_idname = "mantapro_v_mix.add"
    bl_label = "Edit"
    bl_description = "Add VMix modifier"

    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return not polls.V_MOD_MOD(context, "MIX")

    def execute(self, context):
        add_mod(context, "MIX")

        # open panel
        # panel = panels.get_panels(context)
        # panel.v_mod_mix = True
        return {'FINISHED'}


class MantaProEffectsVProxAdd(bpy.types.Operator):
    bl_idname = "mantapro_v_prox.add"
    bl_label = "Edit"
    bl_description = "Add VProximity modifier"

    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return not polls.V_MOD_MOD(context, "PROX")

    def execute(self, context):
        add_mod(context, "PROX")
        # open panel
        # panel = panels.get_panels(context)
        # panel.v_mod_prox = True
        return {'FINISHED'}


class MantaProEffectsAddVGroup(bpy.types.Operator):
    bl_idname = "mantapro_v_edit.add_vgroup"
    bl_label = "Add Vertex Group"
    bl_description = "Add Vertex Group"

    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD(context)

    def execute(self, context):
        effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
        obj = context.scene.MantaPro.active_flow
        modifier_settings = modifiers.find_modifier(
            obj).flow_settings

        if not "MantaPro" in obj.vertex_groups:
            vgroup = obj.vertex_groups.new(name="MantaPro")
        else:
            vgroup = obj.vertex_groups["MantaPro"]
        modifier_settings.density_vertex_group = "MantaPro"
        effect.vgroup = vgroup.name

        return {'FINISHED'}


class MantaProEffectsSyncVGroup(bpy.types.Operator):
    bl_idname = "mantapro_v_edit.sync_vgroup"
    bl_label = "Sync Vertex Group"
    bl_description = "Sync Vertex Group to modifiers"

    bl_options = {'REGISTER', 'UNDO'}

    match_to: bpy.props.StringProperty()

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD(context)

    def execute(self, context):
        effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
        obj = context.scene.MantaPro.active_flow
        modifier_settings = modifiers.find_modifier(
            obj).flow_settings

        effect.vgroup = modifier_settings.density_vertex_group

        return {'FINISHED'}


class MantaProEffectsProxRemove(bpy.types.Operator):
    bl_idname = "mantapro_v_prox.remove"
    bl_label = "Remove Proximity"
    bl_description = "remove VProximity modifier"
    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD_MOD(context, "PROX")

    def execute(self, context):
        remove_mod(context, "PROX")

        # close panel
        panel = panels.get_panels(context)
        panel.v_mod_prox = False
        return {'FINISHED'}


class MantaProEffectsMixRemove(bpy.types.Operator):
    bl_idname = "mantapro_v_mix.remove"
    bl_label = "Remove Mix"
    bl_description = "remove VMix modifier"
    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD_MOD(context, "MIX")

    def execute(self, context):
        remove_mod(context, "MIX")

        # close panel
        panel = panels.get_panels(context)
        panel.v_mod_mix = False
        return {'FINISHED'}


class MantaProEffectsEditRemove(bpy.types.Operator):
    bl_idname = "mantapro_v_edit.remove"
    bl_label = "Remove Edit"
    bl_description = "remove VEdit modifier"
    bl_options = {'REGISTER', 'UNDO'}

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD_MOD(context, "EDIT")

    def execute(self, context):
        remove_mod(context, "EDIT")

        # close panel
        panel = panels.get_panels(context)
        panel.v_mod_edit = False
        return {'FINISHED'}


class MantaProEffectsFixMod(bpy.types.Operator):
    bl_idname = "mantapro_v.fix"
    bl_label = "Fix Missing"
    bl_description = "Fix Missing modifier"
    bl_options = {'REGISTER', 'UNDO'}

    type: bpy.props.StringProperty(name="type")

    @ classmethod
    def poll(cls, context):
        return polls.V_MOD(context,)

    def execute(self, context):
        add_mod(context, self.type)
        return {'FINISHED'}


class MantaProEffectVPaintStart(bpy.types.Operator):
    bl_idname = "mantapro_v.paint_start"
    bl_label = "Start Painting"
    bl_description = "Paint flow influence on selected object \n NOTE: works best on higher poly objects"

    @ classmethod
    def poll(cls, context):
        return polls.FLOW_GAS(context)

    def execute(self, context):
        v_mod = Effects.get_active(context).v_mod
        obj = v_mod.source
        modifier_settings = modifiers.find_modifier(obj).flow_settings

        if not "MantaPro" in obj.vertex_groups:
            obj.vertex_groups.new(name="MantaPro")

        modifier_settings.density_vertex_group = "MantaPro"

        context.view_layer.objects.active = obj
        obj.select_set(True)

        bpy.ops.paint.weight_paint_toggle()
        obj.vertex_groups.active = obj.vertex_groups[
            "MantaPro"]
        return {'FINISHED'}


"""
 █████  █████ █████
░░███  ░░███ ░░███
 ░███   ░███  ░███
 ░███   ░███  ░███
 ░███   ░███  ░███
 ░███   ░███  ░███
 ░░████████   █████
  ░░░░░░░░   ░░░░░
"""


def ui_header(row: bpy.types.UILayout, mod):
    if mod == "EDIT":
        row.operator("mantapro_v_edit.add", text="", icon="ADD")
        row.operator("mantapro_v_edit.remove", text="", icon="REMOVE")
    elif mod == "MIX":
        row.operator("mantapro_v_mix.add", text="", icon="ADD")
        row.operator("mantapro_v_mix.remove", text="", icon="REMOVE")
    elif mod == "PROX":
        row.operator("mantapro_v_prox.add", text="", icon="ADD")
        row.operator("mantapro_v_prox.remove", text="", icon="REMOVE")

    # row.label(icon='REMOVE')


def _report_mismatch(self: uiCore.Core):
    self.set_layout("col")
    self.alert()
    self.label(
        "Vertex modifier and flow object vertex group do not match", icon="ERROR")
    self.separator()
    self.operator("mantapro_v_edit.sync_vgroup")
    self.separator()


def ui_check(self: uiCore.Core, context: bpy.context):
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    obj = effect.source
    fluid_modifier = modifiers.find_modifier(obj).flow_settings

    # props
    self.operator("mantapro_v.paint_start", icon="BRUSHES_ALL")

    self.label_prop(effect, "source", text="Source Object")

    self.label("Vertex Group:")
    self.ui.prop_search(effect, "vgroup",
                                obj, "vertex_groups", text="")

    # flow has vertex group
    if not fluid_modifier.density_vertex_group:
        self.set_layout("col")
        self.alert()
        self.label(
            text="No Vertex Group is set on the Flow Object", icon="ERROR")
        self.operator("mantapro_v_edit.add_vgroup")
        self.separator()

    self.reset()


def _influence(self: uiCore.Core, panel, obj, modifier, main_panel_id: str, texture_panel_id: str, color_panel_id: str):
    # influence
    with self.sub_panel(panel, main_panel_id, box_header=False, text="Influence") as sub:
        sub()
        self.set_layout("col", align=True)
        self.separator()
        self.prop(modifier, "mask_constant")
        self.separator()
        #
        self.label("Mask Vertex Group")
        self.set_layout("row", align=True)
        self.ui.prop_search(
            modifier, "mask_vertex_group", obj, "vertex_groups", text="")
        self.prop(modifier, "invert_mask_vertex_group",
                  icon_only=True, icon="ARROW_LEFTRIGHT")

        self.set_layout("col")
        self.label("Mask Texture")
        if modifier.mask_texture:
            self.ui.template_ID_preview(
                modifier, "mask_texture", new="texture.new")
        else:
            self.ui.template_ID(
                modifier, "mask_texture", new="texture.new")

        if modifier.mask_texture:
            self.label_prop(
                modifier, "mask_tex_use_channel", text="Channel")
            self.label_prop(modifier, "mask_tex_mapping",
                            text="Texture Coordinates")

            self.separator()

            # texture
            with self.sub_panel(panel, texture_panel_id, text="Texture", box_header=False) as sub:
                sub()
                self.set_layout("col", align=True)
                ui_textures.ui(self, modifier.mask_texture)

                self.separator()

                # color
                with self.sub_panel(panel, color_panel_id, text="Color", box_header=False) as sub:
                    sub()
                    ui_textures.draw_color(self, modifier.mask_texture)


panels.add("v_edit_default")
panels.add("v_edit_influence")
panels.add("v_edit_texture")
panels.add("v_edit_texture_color")


def ui_draw_edit(self: uiCore.Core, context: bpy.context):
    panel = panels.get_panels(context)
    self.set_layout("col", align=True)
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    obj = effect.source
    fluid_modifier = modifiers.find_modifier(obj).flow_settings

    # has edit
    if not effect.use_edit:
        self.label("Edit has not yet been added", icon="ERROR")
    modifier = modifiers.get_v_mod(effect, obj, "EDIT")

    # has modifier
    if modifier:

        # flow modifier mismatch
        if modifier.vertex_group != fluid_modifier.density_vertex_group:
            _report_mismatch(self)
            self.reset()

        # main
        self.set_layout("row", align=True)
        self.label_prop(modifier, "falloff_type", text="Falloff", as_row=True)
        self.prop(modifier, "invert_falloff",
                  icon_only=True, icon="ARROW_LEFTRIGHT")
        self.set_layout("col")
        if modifier.falloff_type == "CURVE":
            self.ui.template_curve_mapping(modifier, "map_curve")

        #  influence
        _influence(self, panel, obj, modifier, "v_edit_influence",
                   "v_edit_texture", "v_edit_texture_color")

        # Defaults
        with self.sub_panel(panel, "v_edit_default", box_header=False, text="Defaults") as sub:
            sub()
            self.set_layout("col", align=True, reset=True)

            self.prop(modifier, "default_weight")
            self.separator()

            self.icon_prop(modifier, "use_add")
            if modifier.use_add:
                self.prop(modifier, "add_threshold", text="Threshold")
            self.separator()

            self.icon_prop(modifier, "use_remove")
            if modifier.use_remove:
                self.prop(modifier, "remove_threshold", text="Threshold")

            self.separator()
            self.icon_prop(modifier, "normalize")
            self.separator()

    else:
        if effect.use_edit:
            self.set_layout("col")
            self.alert()
            self.label("Vertex Modifier is Missing", icon="ERROR")
            self.operator("mantapro_v.fix", settings={
                          "type": "EDIT"}, icon="TOOL_SETTINGS")
            self.reset()


panels.add("v_mix_default")
panels.add("v_mix_influence")
panels.add("v_mix_texture")
panels.add("v_mix_texture_color")


def ui_draw_mix(self: uiCore.Core, context: bpy.context):
    panel = panels.get_panels(context)
    self.set_layout("col", align=True)
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    obj = effect.source
    fluid_modifier = modifiers.find_modifier(obj).flow_settings

    # has mod
    if not effect.use_mix:
        self.label("Mix has not yet been added", icon="ERROR")
    modifier = modifiers.get_v_mod(effect, obj, "MIX")

    # has modifier
    if modifier:

        # flow modifier mismatch
        if modifier.vertex_group_a != fluid_modifier.density_vertex_group:
            _report_mismatch(self)
            self.reset()

        # main
        self.set_layout("col", align=True)
        self.label("Mix Vertex Group:")
        self.set_layout("row", align=True)
        self.ui.prop_search(modifier, "vertex_group_b",
                            obj, "vertex_groups", text="")
        self.prop(modifier, "invert_vertex_group_b",
                  icon="ARROW_LEFTRIGHT", icon_only=True)

        self.set_layout("col", align=True)

        self.separator()
        self.label_prop(modifier, "mix_set", text="Vertex Set")

        # self.separator()
        self.label_prop(modifier, "mix_mode", text="Mix Mode")

        self.separator()
        self.icon_prop(modifier, "normalize")

        # influence
        self.separator()
        _influence(self, panel, obj, modifier, "v_mix_influence",
                   "v_mix_texture", "v_mix_texture_color")

        # Defaults
        self.separator()
        with self.sub_panel(panel, "v_mix_default", box_header=False, text="Defaults") as sub:
            sub()
            self.set_layout("col", align=True, reset=True)

            self.prop(modifier, "default_weight_a")
            # self.separator()
            self.prop(modifier, "default_weight_b")

    else:
        if effect.use_mix:
            self.set_layout("col")
            self.alert()
            self.label("Vertex Modifier is Missing", icon="ERROR")
            self.operator("mantapro_v.fix", settings={
                          "type": "MIX"}, icon="TOOL_SETTINGS")
            self.reset()


panels.add("v_mix_falloff")
panels.add("v_mix_influence")
panels.add("v_mix_texture")
panels.add("v_mix_texture_color")


def ui_draw_prox(self: uiCore.Core, context: bpy.context):
    panel = panels.get_panels(context)
    self.set_layout("col", align=True)
    effect = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].v_mod
    obj = effect.source
    fluid_modifier = modifiers.find_modifier(obj).flow_settings

    # has mod
    if not effect.use_proximity:
        self.label("Proximity has not yet been added", icon="ERROR")
    modifier = modifiers.get_v_mod(effect, obj, "PROX")

    if modifier:

        # flow modifier mismatch
        if modifier.vertex_group != fluid_modifier.density_vertex_group:
            _report_mismatch(self)
            self.reset()

        # main
        self.label_prop(modifier, "proximity_mode")
        if modifier.proximity_mode == 'GEOMETRY':
            self.set_layout('row')
            self.prop(modifier, 'proximity_geometry')
            self.set_layout('col')

        self.label_prop(modifier, "target", text="Target Object")
        self.separator()

        self.prop(modifier, "min_dist")
        self.prop(modifier, "max_dist")
        self.separator()

        self.icon_prop(modifier, "normalize")
        self.separator()

        # Falloff
        with self.sub_panel(panel, "v_mix_falloff", text="Falloff", box_header=False) as sub:
            sub()
            self.set_layout("row", align=True)
            self.label_prop(modifier, "falloff_type",
                            text="Falloff", as_row=True)
            self.prop(modifier, "invert_falloff",
                      icon_only=True, icon="ARROW_LEFTRIGHT")
            self.set_layout("col")
            if modifier.falloff_type == "CURVE":
                self.ui.template_curve_mapping(modifier, "map_curve")

        self.separator()

        # influence
        _influence(self, panel, obj, modifier, "v_mix_influence",
                   "v_mix_texture", "v_mix_texture_color")
    else:
        if effect.use_proximity:
            self.set_layout("col")
            self.alert()
            self.label("Vertex Modifier is Missing", icon="ERROR")
            self.operator("mantapro_v.fix", settings={
                          "type": "PROX"}, icon="TOOL_SETTINGS")
            self.reset()


def ui_add_op(layout: bpy.types.UILayout, settings):
    col = layout.column()
    col.template_list("OBJECT_UL_flows", "", settings,
                      "flows", settings, "flows_index")
    col.separator()
    col.label(text="Vertex Modify will be added to selected the Flow")
    if modifiers.check_type_liquid(settings.active_flow, "FLOW"):
        col = layout.column()
        col.alert = True
        col.label(
            text="Vertex Modify effect is not support on a Liquid flow", icon="ERROR")


classes = [MantaProEffectsVEditEdit,
           MantaProEffectsAddVGroup,
           MantaProEffectsSyncVGroup,

           MantaProEffectsVMixAdd,
           MantaProEffectsVProxAdd,

           MantaProEffectsEditRemove,
           MantaProEffectsMixRemove,
           MantaProEffectsProxRemove,

           MantaProEffectsFixMod,
           MantaProEffectVPaintStart, ]


def register():
    for i in classes:
        bpy.utils.register_class(i)


def unregister():
    for i in classes:
        bpy.utils.unregister_class(i)
