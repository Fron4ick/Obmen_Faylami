import bpy

o_active_object = bpy.context.active_object
o_selected_objects = bpy.context.selected_objects

bpy.ops.mesh.primitive_grid_add(x_subdivisions=100, y_subdivisions=100, size=10,
                                enter_editmode=False, align='WORLD', location=(0, 0, 4), scale=(1, 1, 1))

ocean = bpy.context.active_object

solidify_mod = ocean.modifiers.new("MP-Solidify", type='SOLIDIFY')
solidify_mod.thickness = 7

ocean_mod = ocean.modifiers.new("MP-Ocean", type='OCEAN')
ocean_mod.geometry_mode = 'DISPLACE'
ocean_mod.size = 0.3
ocean_mod.use_normals

fluid_modifier = ocean.modifiers.new("Fluid", type='FLUID')
fluid_modifier.fluid_type = 'FLOW'
flow = fluid_modifier.flow_settings

flow.flow_type = 'LIQUID'
flow.flow_behavior = 'GEOMETRY'
flow.use_initial_velocity = True
flow.velocity_normal = 1.0
