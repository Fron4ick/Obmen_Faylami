# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import bpy


def find_modifier(obj):
    # return obj.modifiers["Fluid"]
    if obj:
        for modifier in obj.modifiers:
            if modifier.type == "FLUID":
                return modifier
    return None


def check_category(obj):
    """check and return the type of object it is (LIQUID, GAS, COLLISTION, SMOKE, etc...)"""
    if obj:
        settings = find_modifier(obj)
        if settings:
            if settings.fluid_type == "DOMAIN":
                return settings.domain_settings.domain_type
            elif settings.fluid_type == "FLOW":
                return settings.flow_settings.flow_type
            elif settings.fluid_type == "EFFECTOR":
                return settings.effector_settings.effector_type
    return None


def check_type_gas(obj, kind):
    """check for a modifier of a kind and if type is gas

    possable kind: 'DOMAIN', 'FLOW', 'EFFECTOR'
    """
    if not obj:
        return False

    modifier = find_modifier(obj)
    if modifier:
        if modifier.fluid_type == kind:

            if kind == "EFFECTOR":
                return True

            elif kind == "DOMAIN":
                if modifier.domain_settings.domain_type == 'GAS':
                    return True

            elif kind == "FLOW":
                if modifier.flow_settings.flow_type != 'LIQUID':
                    return True
    return False


def check_type_liquid(obj, kind):
    """check for a modifier of a kind and if type is liquid

    possable kind: 'DOMAIN', 'FLOW', 'EFFECTOR'
    """
    if not obj:
        return False

    if find_modifier(obj):
        if find_modifier(obj).fluid_type == kind:

            if kind == "EFFECTOR":
                return True

            elif kind == "DOMAIN":
                if find_modifier(obj).domain_settings.domain_type == 'LIQUID':
                    return True

            elif kind == "FLOW":
                if find_modifier(obj).flow_settings.flow_type == 'LIQUID':
                    return True
    return False


def get_modifier_domain(context=None, domain=None):
    """get domain modifier settings"""
    modifier_settings = None

    if domain:
        modifier_settings = find_modifier(domain).domain_settings

    elif context:
        domain = context.scene.MantaPro.active_domain
        if domain:
            modifier_settings = find_modifier(domain).domain_settings

    return modifier_settings


def find_ember_modifier(flow):
    for i in flow.modifiers:
        if i.type == "PARTICLE_SYSTEM":
            if i.particle_system.settings.MantaPro.is_ember:
                return i
    return None


def get_v_mod(effect, obj, mod: str):
    """return the modifier for the V_MOD based on the 'mod' key

    if no modifier is found returns False

    possible mod: 'EDIT', 'MIX', 'PROX'
    """

    key = ''
    if mod == 'EDIT':
        key = effect.edit
    elif mod == 'MIX':
        key = effect.mix
    elif mod == 'PROX':
        key = effect.proximity

    if not key:
        return False

    try:
        modifier = obj.modifiers[key]
        return modifier
    except KeyError:
        return False


def get_v_mod_all(effect, obj):
    """Returns all modifier for the V_MOD (EDIT, MIX, PROXIMITY)"""
    return get_v_mod(effect, obj, "EDIT"), get_v_mod(effect, obj, "MIX"), get_v_mod(effect, obj, "PROX")


def get_modifier_index(obj, modifier_name: str) -> int:
    """Finds the index of any modifier in the modifier stack

    returns none if not found"""
    index = 0

    for key in obj.modifiers.keys():
        if key == modifier_name:
            return index
        index += 1

    return None


def get_modifier(obj, key):
    """get a modifier given the object and the key

    returns False if not found
    """
    try:
        modifier = obj.modifiers[key]
        return modifier
    except KeyError:
        return False
