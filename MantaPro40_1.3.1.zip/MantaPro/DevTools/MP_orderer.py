import sys
import shutil
import os


def one_file(file_path, classes_dict):
    file = open(file_path, "r")

    new_file = []
    lines = file.read().split("\n")
    is_checking = 0
    rewrite = []
    c_key = ""
    for i in range(len(lines)):
        line = lines[i]
        new_file.append(line + "\n")
        if is_checking > 0:
            is_checking += 1
            if "MP_order_id" in line:
                rewrite.append([i, classes_dict[c_key]])
        if "class " in line:
            # print(line)
            c = line.split("(")[0][6:]
            for key in classes_dict.keys():
                if c == key:
                    is_checking = 1
                    c_key = key
    file.close()

    for i in rewrite:
        new_file[i[0]] = "    MP_order_id = " + str(i[1]) + "\n"

    with open(file_path, "w") as file:
        file.writelines(new_file)


def one_pass(file_path, classes_dict):
    if not os.path.exists("backup"):
        os.makedirs("backup")
    shutil.copyfile(file_path, "backup\\" + file_path.replace(os.sep, "_"))
    one_file(file_path, classes_dict)

    print(file_path, "fineshed a pass")


def main():
    files = [
        ".\\Panels\\domain.py",
        ".\\Panels\\effector.py",
        ".\\Panels\\ember.py",
        ".\\Panels\\flow.py",
        ".\\Panels\\force.py",
        ".\\Panels\\other.py",

        ".\\Gas\\Panels\\domain.py",
        ".\\Gas\\Panels\\effector.py",
        ".\\Gas\\Panels\\flow.py",

        ".\\Liquid\\Panels\\domain.py",
        ".\\Liquid\\Panels\\effector.py",
        ".\\Liquid\\Panels\\flow.py",
    ]
    classes = {
        'VIEW3D_PT__ALL__Workspace': 0,
        'OBJECT_UL_domains': 1,
        'OBJECT_UL_flows': 2,
        'OBJECT_UL_effector': 3,
        'OBJECT_UL_force': 4,
        'VIEW3D_PT__ALL__AutoOpsSettings': 5,
        'VIEW3D_PT__SIM__MantaPro': 6,
        'VIEW3D_PT__SIM__MantaProDomain': 7,
        'VIEW3D_PT__SIM__MantaProFlowMain': 8,
        'VIEW3D_PT__SIM__GasBlender': 9,
        'VIEW3D_PT__SIM__MantaProFlow': 10,
        'VIEW3D_PT__SIM__DissolveBlender': 11,
        'VIEW3D_PT__SIM__FlowSourceSub': 12,
        'VIEW3D_PT__SIM__NoiseBlender': 13,
        'VIEW3D_PT__SIM__MantaProEffectorMain': 14,
        'VIEW3D_PT__SIM__FireBlender': 15,
        'VIEW3D_PT__SIM__MantaProEffector': 16,
        'VIEW3D_PT__SIM__EffectorDisplaySubGas': 17,
        'VIEW3D_PT__SIM__MantaProForceMain': 18,
        'VIEW3D_PT__SIM__MantaProForce': 19,
        'VIEW3D_PT__SIM__MantaProForceFalloff': 20,
        'VIEW3D_PT__SIM__MantaProForceKink': 21,
        'VIEW3D_PT__SIM__MantaProForceTexture': 22,
        'VIEW3D_PT__SIM__MantaProForceTextureSettings': 23,
        'VIEW3D_PT__SIM__ForceTextureColorSub': 24,
        'VIEW3D_PT__SIM__MantaProForceFalloffRadial': 25,
        'VIEW3D_PT__SIM__MantaProPanelPaint': 26,
        'VIEW3D_PT__SIM__SaveSetup': 27,
        'VIEW3D_PT__SIM__RemoveSetup': 28,
        'VIEW3D_PT__SIM__ExportImportSetup': 29,
        'VIEW3D_PT__SIM__ViewSetup': 30,
        'VIEW3D_PT__SIM__DomainParticelsSub': 31,
        'VIEW3D_PT__SIM__DomainParticelsCustomSub': 32,
        'VIEW3D_PT__SIM__AdvancedParticelsSub': 33,
        'VIEW3D_PT__SIM__DomainNoiseSub': 34,
        'VIEW3D_PT__SIM__DomainFireSub': 35,
        'VIEW3D_PT__SIM__FlowVertexGroupSub': 36,
        'VIEW3D_PT__SIM__DomainMaterialSub': 37,
        'VIEW3D_PT__SIM__DomainGuidesSub': 38,
        'VIEW3D_PT__SIM__DomainCollectionsSub': 39,
        'VIEW3D_PT__SIM__DomainBorderSub': 40,
        'VIEW3D_PT__SIM__DomainFieldSub': 41,
        'VIEW3D_PT__SIM__DomainAdvancedSub': 42,
        'VIEW3D_PT__SIM__FlowVelocitySub': 43,
        'VIEW3D_PT__SIM__BlenderLiquid': 44,
        'VIEW3D_PT__SIM__DomainBorderBlenderSub': 45,
        'VIEW3D_PT__SIM__BlenderViscosity': 46,
        'VIEW3D_PT__SIM__BlenderDiffusion': 47,
        'VIEW3D_PT__SIM__BlenderParticles': 48,
        'VIEW3D_PT__SIM__BlenderMesh': 49,
        'VIEW3D_PT__SIM__BlenderGuides': 50,
        'VIEW3D_PT__SIM__BlenderCollections': 51,
        'VIEW3D_PT__SIM__BlenderCache': 52,
        'VIEW3D_PT__SIM__BlenderCacheAdvanced': 53,
        'VIEW3D_PT__SIM__BlenderFieldWeights': 54,
        'VIEW3D_PT__SIM__CacheBlenderToolsSub': 55,
        'VIEW3D_PT__SIM__Viewport': 56,
        'VIEW3D_PT__SIM__BlenderViewport': 57,
        'VIEW3D_PT__SIM__ViewportSlice': 58,
        'VIEW3D_PT__SIM__BlenderViewportSlice': 59,
        'VIEW3D_PT__SIM__ViewportGrid': 60,
        'VIEW3D_PT__SIM__BlenderViewportGrid': 61,
        'VIEW3D_PT__SIM__ViewportVector': 62,
        'VIEW3D_PT__SIM__BlenderViewportVector': 63,
        'VIEW3D_PT__SIM__DomainParticleBlenderToolsSub': 64,
        'VIEW3D_PT__SIM__DomainBlenderToolsSub': 65,
        'VIEW3D_PT__SIM__DomainMaterailBlenderToolsSub': 66,
        'VIEW3D_PT__SIM__FlowSourceBlender': 67,
        'VIEW3D_PT__SIM__FlowVelocityBlender': 68,
        'VIEW3D_PT__SIM__AdvancedDiffusionSub': 69,
        'VIEW3D_PT__SIM__AdvancedLiquidSub': 70,
        'VIEW3D_PT__SIM__AdvancedMeshSub': 71,
        'VIEW3D_PT__SIM__FlowTextureSub': 72,
        'VIEW3D_PT__SIM__FlowTextureSettingsSub': 73,
        'VIEW3D_PT__SIM__FlowTextureColorSub': 74,
        'VIEW3D_PT__SIM__AdvancedGasSub': 75,
        'VIEW3D_PT__SIM__AdvancedAdaptiveGasSub': 76,
        'VIEW3D_PT__SIM__AdvancedGravitySub': 77,
        'VIEW3D_PT__SIM__AdvancedCacheSub': 78,
        'VIEW3D_PT__SIM__FlowEmberSub': 79,
        'VIEW3D_PT__SIM__FlowDisplaySubGas': 80,
        'VIEW3D_PT__SIM__EmberSettingsSub': 81,
        'VIEW3D_PT__SIM__FlowToolsBlender': 82,
        'VIEW3D_PT__SIM__EmberParticleSub': 83,
        'VIEW3D_PT__SIM__EmberCustomParticleSub': 84,
        'VIEW3D_PT__SIM__EmberForceSub': 85,
        'VIEW3D_PT__SIM__EmberCacheSub': 86,
        'VIEW3D_PT__SIM__EmberForceFalloffSub': 87,
        'VIEW3D_PT__SIM__EmberMaterialSub': 88,
        'VIEW3D_PT__ALL__DEV': 89,
    }

    for file in files:
        one_pass(file, classes)
        print(file, os.path.exists(file))


if __name__ == '__main__':
    main()
