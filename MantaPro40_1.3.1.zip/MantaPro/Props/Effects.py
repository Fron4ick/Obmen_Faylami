# Copyright (C) <2022>  <Reston Stanton>

# ##### BEGIN GPL LICENSE BLOCK #####
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
from ..Shared import modifiers, particles
from ..Effects import v_mod

"""
                          █████            █████
                         ░░███            ░░███
 █████ ████ ████████   ███████   ██████   ███████    ██████
░░███ ░███ ░░███░░███ ███░░███  ░░░░░███ ░░░███░    ███░░███
 ░███ ░███  ░███ ░███░███ ░███   ███████   ░███    ░███████
 ░███ ░███  ░███ ░███░███ ░███  ███░░███   ░███ ███░███░░░
 ░░████████ ░███████ ░░████████░░████████  ░░█████ ░░██████
  ░░░░░░░░  ░███░░░   ░░░░░░░░  ░░░░░░░░    ░░░░░   ░░░░░░
            ░███
            █████
           ░░░░░
"""
updating = False


def update_ember_domain(self, context):
    ember = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].ember
    force = ember.force_object
    if force:
        force.field.source_object = self.domain


def poll_ember_domain(self, object):
    modifier = modifiers.find_modifier(object)
    if modifier:
        if modifier.fluid_type == "DOMAIN":
            return True
    return False


def poll_vmod_source(self, object):
    modifier = modifiers.find_modifier(object)
    if modifier:
        if modifier.fluid_type == "FLOW":
            if modifier.flow_settings.flow_type != "LIQUID":
                return True
    return False


def ember_use_sub_force(self, context):
    global updating
    if not updating:
        updating = True
        ember = context.scene.MantaPro.effects[context.scene.MantaPro.effects_index].ember
        system = particles.find_ember_system(ember.emitter_object)
        settings = system.settings
        force_settings = settings.force_field_1

        if self.ember_use_sub_force:
            force_settings.type = "FORCE"
        else:
            force_settings.type = "NONE"

        updating = False


def update_v_group_mod(self, context):
    value = self.vgroup
    v_edit, v_mix, v_prox = modifiers.get_v_mod_all(self, self.source)
    if v_edit:
        v_edit.vertex_group = value
    if v_mix:
        v_mix.vertex_group_a = value
    if v_prox:
        v_prox.vertex_group = value

    fluid_modifier = modifiers.find_modifier(self.source).flow_settings
    fluid_modifier.density_vertex_group = value


def update_vmod_source(self, context):
    v_mod.move_all(context, self.source, self.prev_source)
    self.prev_source.MantaPro.is_vmod = False
    self.source.MantaPro.is_vmod = True
    self.prev_source = self.source


def update_animate_time(self, context):
    ocean = self.ocean
    speed = self.animation_speed
    frame_start = context.scene.frame_start
    frame_end = context.scene.frame_end

    modifier = modifiers.get_modifier(ocean, self.ocean_mod)
    if modifier:

        if self.animate_time:
            modifier.keyframe_insert(
                "time", frame=frame_start)

            modifier.time = frame_end * (speed / 10)
            modifier.keyframe_insert(
                "time", frame=frame_end)

            f_curve = ocean.animation_data.action.fcurves.find(
                modifier.path_from_id("time"))

            for i in f_curve.keyframe_points:
                i.interpolation = "LINEAR"

        else:
            f_curve = ocean.animation_data.action.fcurves.find(
                modifier.path_from_id("time"))
            ocean.animation_data.action.fcurves.remove(f_curve)


def update_ocean_scale(self, context):
    obj = self.ocean
    obj.scale[0] = self.scale
    obj.scale[1] = self.scale


def update_ocean_power(self, context):
    flow = modifiers.find_modifier(self.ocean)
    if flow:
        flow = flow.flow_settings
        flow.velocity_factor = self.power
        flow.velocity_normal = self.power


def update_ocean_subdiv(self, context):
    subdiv_mod = modifiers.get_modifier(self.ocean, self.subdiv_mod)
    if subdiv_mod:
        subdiv_mod.levels = self.subdiv_levels
        subdiv_mod.render_levels = self.subdiv_levels


"""
          ████
         ░░███
  ██████  ░███   ██████    █████   █████   ██████   █████
 ███░░███ ░███  ░░░░░███  ███░░   ███░░   ███░░███ ███░░
░███ ░░░  ░███   ███████ ░░█████ ░░█████ ░███████ ░░█████
░███  ███ ░███  ███░░███  ░░░░███ ░░░░███░███░░░   ░░░░███
░░██████  █████░░████████ ██████  ██████ ░░██████  ██████
 ░░░░░░  ░░░░░  ░░░░░░░░ ░░░░░░  ░░░░░░   ░░░░░░  ░░░░░░



"""


class Effect(bpy.types.PropertyGroup):
    version: bpy.props.IntProperty(default=1)


class MantaProEmberEffect(Effect):
    # ember
    emitter_object: bpy.props.PointerProperty(type=bpy.types.Object)
    particle_object: bpy.props.PointerProperty(type=bpy.types.Object)
    force_object: bpy.props.PointerProperty(type=bpy.types.Object)

    domain: bpy.props.PointerProperty(
        type=bpy.types.Object, update=update_ember_domain, poll=poll_ember_domain)

    use_sub_force: bpy.props.BoolProperty(
        name="Use Sub Force", default=True, update=ember_use_sub_force)


class MantaProVModEffect(Effect):
    # v_mod
    source: bpy.props.PointerProperty(
        type=bpy.types.Object, poll=poll_vmod_source, update=update_vmod_source)

    prev_source: bpy.props.PointerProperty(type=bpy.types.Object)

    vgroup: bpy.props.StringProperty(
        update=update_v_group_mod)

    use_edit: bpy.props.BoolProperty()
    edit: bpy.props.StringProperty()

    use_mix: bpy.props.BoolProperty()
    mix: bpy.props.StringProperty()

    use_proximity: bpy.props.BoolProperty()
    proximity: bpy.props.StringProperty()


class MantaProOceanEffect(Effect):
    domain: bpy.props.PointerProperty(type=bpy.types.Object)
    ocean: bpy.props.PointerProperty(type=bpy.types.Object)

    ocean_mod: bpy.props.StringProperty()
    solidify_mod: bpy.props.StringProperty()
    subdiv_mod: bpy.props.StringProperty()

    animate_time: bpy.props.BoolProperty(
        name="Animate Time", default=False, description="animate texture", update=update_animate_time)
    animation_speed: bpy.props.FloatProperty(
        name="Speed", default=0.5, soft_max=1, soft_min=0, precision=3, update=update_animate_time)

    scale: bpy.props.FloatProperty(
        name="Scale", default=1.0, description="Scale ocean on the x and y axis", update=update_ocean_scale)

    subdiv_levels: bpy.props.IntProperty(name="Subdivision", description="Viewport and render subdivision levels",
                                         default=0, min=0, soft_max=4, max=11, update=update_ocean_subdiv)

    power: bpy.props.FloatProperty(
        name="Power", default=1.0, description="The amount of velocity given to the fluid", soft_max=25, soft_min=-25, min=-100, max=100, update=update_ocean_power)


class MantaProEffects(bpy.types.PropertyGroup):
    ember: bpy.props.PointerProperty(type=MantaProEmberEffect)
    v_mod: bpy.props.PointerProperty(type=MantaProVModEffect)
    ocean: bpy.props.PointerProperty(type=MantaProOceanEffect)

    type: bpy.props.EnumProperty(items=[("EMBER", "Ember", "", 0, 0),
                                        ("OCEAN", "Ocean to Liquid", "", 0, 1),
                                        ("EXPLODE", "Explode Tools", "", 0, 2),
                                        ("FLOAT", "Float on Liquid", "", 0, 3),
                                        ("V_MOD", "Modify Vertex", "", 0, 4),
                                        ("V_DYNAMIC", "Dynamic Vertex", "", 0, 5)])
    name: bpy.props.StringProperty(
        name="Name", subtype='NONE', default="default name")
    index: bpy.props.IntProperty(
        name="Index", subtype='NONE', default=0, min=0)


classes = [
    MantaProEmberEffect,
    MantaProVModEffect,
    MantaProOceanEffect,
    MantaProEffects,
]


def register():
    for i in classes:
        bpy.utils.register_class(i)


def unregister():
    for i in classes:
        bpy.utils.unregister_class(i)
