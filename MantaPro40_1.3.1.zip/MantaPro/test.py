import inspect

list1 = [1, 2, 3, 4, 5]
list2 = ["string", "num", "item", "thing"]
list3 = [6, 7, 8, 9, 10]


for i in list1, list2, list3:
    for j in i:
        print(j)


def draw_domain(self, context):
    ui_type = 'SIMPLIFIED'
    action = ui_type.lower() + "." + "draw_domain" + "(self, context)"
    print(action)
    exec(action)

    if ui_type == 'DEFAULT':

        print("default.draw_domain(self, context)")
    elif ui_type == 'SIMPLIFIED':
        print("simplified.draw_domain(self, context)")
    elif ui_type == 'BLENDER':
        print("blender.draw_domain(self, context)")


# draw_domain("test", "test.context")


def print_funcation():
    # print(inspect.stack()[0][3])
    print(print_funcation.__name__)
    print()


# print_funcation()

class Class2:
    MP_order_id = 2.0

    def some_function(self):
        print("Class2 GO!!!")


class Class1:
    MP_order_id = 1.0

    def some_function(self):
        print("Class1 GO!!!")


class Class5:
    MP_order_id = 5.0

    def some_function(self):
        print("Class5 GO!!!")


def sorter(item):
    return item.MP_order_id


classes = [Class2, Class5, Class1]
classes.sort(key=sorter)
print("\n\n\n")
for i in classes:
    print(i.MP_order_id)
    print(i.__name__)


print("\n\n\n")

list1 = ["a1", "b1", "c1"]
list2 = ["a2", "b2", "c2"]
list3 = ["a3", "b3", "c3"]

list1.extend(list2)
list1.extend(list3)
list1.sort()
print(list1)
