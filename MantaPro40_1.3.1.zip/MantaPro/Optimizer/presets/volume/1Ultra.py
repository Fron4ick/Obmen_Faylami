# ORIGINAL
bpy.context.scene.cycles.volume_step_rate = 0.5
bpy.context.scene.cycles.volume_preview_step_rate = 0.5
bpy.context.scene.cycles.volume_max_steps = 2048
