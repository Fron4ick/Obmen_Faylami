# ORIGINAL
bpy.context.scene.cycles.volume_step_rate = 10
bpy.context.scene.cycles.volume_preview_step_rate = 10
bpy.context.scene.cycles.volume_max_steps = 102
