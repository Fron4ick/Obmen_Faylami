# ORIGINAL
bpy.context.scene.cycles.volume_step_rate = 3.33333
bpy.context.scene.cycles.volume_preview_step_rate = 3.33333
bpy.context.scene.cycles.volume_max_steps = 768
